export { default as favicon } from './favicon.svg';
