export default {
	message: 1050,
	modal: 1000,

	select: 10,

	header: 900,
};
