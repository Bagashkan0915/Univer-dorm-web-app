/**
 * 图表相关 样式变量
 */

export default {
	// 图表的 背景线条 颜色
	chartBGLineColor: '#e0e0e0',
};
