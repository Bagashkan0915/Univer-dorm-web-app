export default {
	'kkKZ': 'Kazakh',
	'enUS': 'English',

	// Loading
	commonLoadingHelpText: 'Loading...',

	// Header
	'header_search': 'Search...',
	'header_login': 'Login / Register',
};
