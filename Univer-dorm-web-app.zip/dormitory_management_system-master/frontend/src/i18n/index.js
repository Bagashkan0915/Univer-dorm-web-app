export { default as enUS } from './enUS';

export { default as kkKZ } from './kkKZ';
