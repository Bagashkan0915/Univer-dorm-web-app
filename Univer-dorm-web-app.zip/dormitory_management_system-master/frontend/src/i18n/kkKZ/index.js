export default {
	'kkKZ': 'Қазақша',
	'enUS': 'Ағылшынша',

	// Loading
	commonLoadingHelpText: 'Жүктелуде...',

	// Header
	'header_search': 'Іздеу...',
	'header_login': 'Кіру / Тіркелу',
};
