import styled from 'styled-components';

export const ContentStyledBox = styled.main``;
