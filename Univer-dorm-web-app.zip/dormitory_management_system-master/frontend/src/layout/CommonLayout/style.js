import styled from 'styled-components';

export const CommonLayoutStyledBox = styled.div`
	height: inherit;

	position: relative;

	overflow: hidden auto;
`;
