export { default as CommonLoading } from './CommonLoading';
