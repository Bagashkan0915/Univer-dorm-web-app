import React from 'react';

export default function RegisterPage() {
	return <div className="register-page">Register Page</div>;
}
