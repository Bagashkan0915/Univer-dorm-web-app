import styled from 'styled-components';

export const LandingPageStyledBox = styled.div``;
