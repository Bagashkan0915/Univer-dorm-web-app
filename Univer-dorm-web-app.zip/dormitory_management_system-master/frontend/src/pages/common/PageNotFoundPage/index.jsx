import React from 'react';

export default function PageNotFoundPage() {
	return <div>404</div>;
}
