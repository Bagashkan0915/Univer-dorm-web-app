import React from 'react';

export default function HomePage() {
	return <div className="home-page"></div>;
}
